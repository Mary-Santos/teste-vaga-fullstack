const fs = require('fs');
const csvParser = require('csv-parser');
const { formatToBRL } = require('intl');
const { CPF, CNPJ } = require('cpf-cnpj-validator');

async function processarCSV(arquivoCSV) {
    let dados = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(arquivoCSV)
            .pipe(csvParser())
            .on('data', (row) => {
                dados.push(row);
            })
            .on('end', () => {
                resolve(dados);
            })
            .on('error', (err) => {
                reject(err);
            });
    });
}

function formatarParaBRL(valor) {
    return formatToBRL(valor);
}

function validarCPFouCNPJ(nrCpfCnpj) {
    return CPF.isValid(nrCpfCnpj) || CNPJ.isValid(nrCpfCnpj);
}

function validarValorPrestacoes(vlTotal, qtPrestacoes, vlPresta) {
    const valorCalculado = vlTotal / qtPrestacoes;
    return valorCalculado === vlPresta;
}

module.exports = {
    processarCSV,
    formatarParaBRL,
    validarCPFouCNPJ,
    validarValorPrestacoes
};
