const { processarCSV } = require('./functions');
const dados = require('./data')

async function main() {
    try {
        const arquivo = dados; 
        const data = await processarCSV(arquivo);


        console.log('Dados processados:', data);
    } catch (error) {
        console.error('Erro ao processar:', error);
    }
}

main();
