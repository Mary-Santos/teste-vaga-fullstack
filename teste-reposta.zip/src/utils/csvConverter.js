const fs = require('fs');
const csvParser = require('csv-parser');

async function parseCSV(arquivoCSV) {
    let dados = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(arquivoCSV)
            .pipe(csvParser())
            .on('data', (row) => {
                dados.push(row);
            })
            .on('end', () => {
                resolve(dados);
            })
            .on('error', (err) => {
                reject(err);
            });
    });
}

module.exports = { parseCSV };
