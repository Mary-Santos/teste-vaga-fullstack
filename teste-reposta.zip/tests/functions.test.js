const { formatarParaBRL, validarCPFouCNPJ, validarValorPrestacoes } = require('../src/functions');


describe('formatarParaBRL', () => {
    test('Formatar corretamente um número como moeda BRL', () => {
        const valor = 1234.56;
        const resultado = formatarParaBRL(valor);
        expect(resultado).toBe('R$ 1.234,56');
    });

    test('Formatar corretamente um número negativo como moeda BRL', () => {
        const valor = -7890.12;
        const resultado = formatarParaBRL(valor);
        expect(resultado).toBe('-R$ 7.890,12');
    });
});

describe('validarCPFouCNPJ', () => {
    test('Deve validar corretamente um CPF válido', () => {
        const cpfValido = '12345678909'; 
        const resultado = validarCPFouCNPJ(cpfValido);
        expect(resultado).toBe(true);
    });

    test('Deve validar corretamente um CNPJ válido', () => {
        const cnpjValido = '12345678000195';
        const resultado = validarCPFouCNPJ(cnpjValido);
        expect(resultado).toBe(true);
    });

    test('Deve rejeitar um número inválido (nem CPF nem CNPJ)', () => {
        const numeroInvalido = '1234567890';
        const resultado = validarCPFouCNPJ(numeroInvalido);
        expect(resultado).toBe(false);
    });
});

describe('validarValorPrestacoes', () => {
    test('Deve validar corretamente os valores de prestações', () => {
        const vlTotal = 1000;
        const qtPrestacoes = 5;
        const vlPresta = 200;
        const resultado = validarValorPrestacoes(vlTotal, qtPrestacoes, vlPresta);
        expect(resultado).toBe(true);
    });

    test('Deve rejeitar valores de prestações inválidos', () => {
        const vlTotal = 1000;
        const qtPrestacoes = 5;
        const vlPrestaInvalido = 201;
        const resultado = validarValorPrestacoes(vlTotal, qtPrestacoes, vlPrestaInvalido);
        expect(resultado).toBe(false);
    });
});
