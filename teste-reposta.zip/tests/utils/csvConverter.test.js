const { parseCSV } = require('../../src/utils/csvConverter');

describe('parseCSV', () => {
    test('Deve processar corretamente um arquivo CSV', async () => {
        const arquivoCSV = '../../src/data/data.csv'
        const resultado = await parseCSV(arquivoCSV);
        expect(resultado).toBeDefined();
        expect(Array.isArray(resultado)).toBe(true);       
    });

    test('Deve lidar com erro ao ler arquivo inexistente', async () => {
        const arquivoInexistente = '../../src/data';
        await expect(parseCSV(arquivoInexistente)).rejects.toThrow();
    });
});
